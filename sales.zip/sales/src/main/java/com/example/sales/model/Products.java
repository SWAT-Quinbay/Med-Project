package com.example.sales.model;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name="product")
public class Products {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(name = "salesid")
    private int salesId;
    @Column(name="productid")
    private int productId;
    @Column(name="sellerid")
    private String retailSellerId;
    @Column(name = "stockordered")
    private int stockOrdered;
    @Column(name = "price")
    private int retailPrice;
    @Column(name = "productname")
    private String productName;
}


