package com.example.sales.Repository;

import com.example.sales.model.Products;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProductRepository extends JpaRepository<Products,String> {
    List<Products> findAllBySalesId(int salesId);
}
