package com.example.sales.Controller;

import com.example.sales.CustomException.SalesIDNotFound;
import com.example.sales.Service.SalesService;
import com.example.sales.model.Products;
import com.example.sales.model.Sales;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("/sales")
public class SalesController {
    @Autowired
    SalesService salesService;
    @GetMapping("/getAll")
    public List<Sales>getAll(){
        return salesService.getAll();
    }
    @PostMapping("/add")
    public Sales add(@RequestBody List<Products>productsList){
        return salesService.add(productsList);
    }
    @GetMapping("/getOne/{salesId}")
    public List<Products> getOne(@PathVariable (name = "salesId") int salesId) throws SalesIDNotFound {
        try {
            List<Products> productsList = salesService.getById(salesId);
            return productsList;
        }
        catch (Exception e){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,e.getMessage());
        }
    }
}
