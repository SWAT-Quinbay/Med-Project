package com.example.sales.Service;

import com.example.sales.CustomException.SalesIDNotFound;
import com.example.sales.Repository.ProductRepository;
import com.example.sales.Repository.SalesRepository;
import com.example.sales.model.Products;
import com.example.sales.model.Sales;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;

@Service
public class SalesServiceImp implements SalesService {
    @Autowired
    SalesRepository salesRepository;

    @Autowired
    ProductRepository productRepository;

    @Value("${retailSellerURL}")
    public String retailSellerURL;

    private RestTemplate restTemplate;

    public SalesServiceImp(RestTemplateBuilder restTemplateBuilder) {

        restTemplate = restTemplateBuilder.build();
    }

    public List<Sales>getAll(){
        return salesRepository.findAll();
    }

    @Override
    public Sales add(List<Products> productsList){
        Sales currentSale=salesRepository.save(new Sales(new Timestamp(System.currentTimeMillis())));;
        for(Products product:productsList){
            product.setSalesId(currentSale.getSalesId());
            productRepository.save(product);
        }
       // System.out.println(retailSellerURL+"update");
        restTemplate.postForObject(retailSellerURL+"update",productsList,boolean.class);
        return currentSale;
    }

    @Override
    public List<Products> getById(int salesId) throws SalesIDNotFound {
        List<Products>productsList=productRepository.findAllBySalesId(salesId);
        if(productsList.isEmpty())
            throw new SalesIDNotFound("Sales ID is not Found");
        return productsList;
    }
}
