package com.example.sales.CustomException;

public class SalesIDNotFound extends Exception{
    public SalesIDNotFound(String str){
        super(str);
    }
}
