package com.example.sales.Service;

import com.example.sales.CustomException.SalesIDNotFound;
import com.example.sales.model.Products;
import com.example.sales.model.Sales;

import java.util.List;

public interface SalesService {
    public List<Sales>getAll();
    public Sales add(List<Products>productsList);

    List<Products> getById(int salesId) throws SalesIDNotFound;
}
