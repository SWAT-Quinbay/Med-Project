package com.example.WholeSalerDatabase.model;

import javax.persistence.*;
//
//@Entity
//@Table(name = "orderstable")
public class OrderDetails {
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String userId;
    private int productId;
    private String productName;
    private int stock;
    private String status;
    private int orderid;

    public int getOrderid() {
        return orderid;
    }

    public void setOrderid(int orderid) {
        this.orderid = orderid;
    }

    public OrderDetails() {
    }

    public OrderDetails(String userId, int productId, String productName, int stock, String status,int orderid) {
        this.userId = userId;
        this.productId = productId;
        this.productName = productName;
        this.stock = stock;
        this.status = status;
        this.orderid = orderid;
    }

//    public int getOrderId() {
//        return orderId;
//    }
//
//    public void setOrderId(int orderId) {
//        this.orderId = orderId;
//    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "OrderDetails{" +
                "orderId=" +id+
                ", userId='" + userId + '\'' +
                ", productId=" + productId +
                ", productName='" + productName + '\'' +
                ", stock=" + stock +
                ", status='" + status + '\'' +
                '}';
    }
}
