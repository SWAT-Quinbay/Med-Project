package com.example.WholeSalerDatabase.model;

public class RequestModel {

    private int count;
    private int productId;
    private String productName;
    private int retailPrice;
    private String retailSeller;
    private String sellerId;
    private int stockInHand;


    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getRetailPrice() {
        return retailPrice;
    }

    public void setRetailPrice(int retailPrice) {
        this.retailPrice = retailPrice;
    }

    public String getRetailSeller() {
        return retailSeller;
    }

    public void setRetailSeller(String retailSeller) {
        this.retailSeller = retailSeller;
    }

    public String getSellerId() {
        return sellerId;
    }

    public void setSellerId(String sellerId) {
        this.sellerId = sellerId;
    }

    public int getStockInHand() {
        return stockInHand;
    }

    public void setStockInHand(int stockInHand) {
        this.stockInHand = stockInHand;
    }
}
