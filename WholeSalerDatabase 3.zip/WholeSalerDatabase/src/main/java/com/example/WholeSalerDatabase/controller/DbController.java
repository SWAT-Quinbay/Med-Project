package com.example.WholeSalerDatabase.controller;

import com.example.WholeSalerDatabase.customException.WholeSalerException;
import com.example.WholeSalerDatabase.model.*;
import com.example.WholeSalerDatabase.service.WholeSalerDatabaseInterface;
import com.example.WholeSalerDatabase.service.WholeSalerDatabaseService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin("*")
@RequestMapping("/wholesaler")
public class DbController {

    public static final Logger LOGGER = LoggerFactory.getLogger(Details.class);

//    @Autowired
//    WholeSalerDatabaseService wholeSalerDatabaseService;

    @Autowired
    WholeSalerDatabaseInterface wholeSalerDatabaseInterface;

    @PostMapping("/addDetails")
    public String addDetail(@RequestBody Details details){
        try {
            wholeSalerDatabaseInterface.addDetails(details);
        }catch (Exception e){
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }

        return "done";
    }

    @GetMapping("/getDetails")
    public List<Details> getDetail(){
        List<Details> details = null;
        System.out.println("get ");
        try {
            details = wholeSalerDatabaseInterface.getDetails();
        }catch (Exception e){
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }

        LOGGER.info(String.format(details.toString()));
        return details;
    }

    @GetMapping("/getDetailById/{id}")
    public String  getDetailById(@PathVariable("id") int id){
        Optional<Details> requestDetails = null;

        try {
            requestDetails = wholeSalerDatabaseInterface.getDetailsById(id);
        }catch (Exception e){
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }

        LOGGER.info(String.format(requestDetails.toString()));
        return "done";
    }

    @GetMapping("/getOrders")
    public List<OrderDetails> getOrders(){
        try {
            return wholeSalerDatabaseInterface.getOrders();
        }catch (Exception e){
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }

    @PostMapping("/updateOrder")
    public String updateOrderTable(@RequestBody RequestModel requestModel) throws WholeSalerException {
        try {
            wholeSalerDatabaseInterface.updateOrder(requestModel);
        }catch (WholeSalerException w){
            throw new WholeSalerException(w.getMessage());
        } catch (Exception e){
            e.printStackTrace();
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
        System.out.println("updateOrder");
        return "done";
    }

    @PostMapping("/decrementStock")
    public List<Details> decrementStock(@RequestBody AcceptOrder acceptOrder) throws WholeSalerException {

        try {
            return wholeSalerDatabaseInterface.decrementStock(acceptOrder);
        }catch (WholeSalerException w){
            throw new WholeSalerException(w.getMessage());
        } catch (Exception e){
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }

    }

    @PostMapping("/declineOrder")
    public String declineOrder(@RequestBody AcceptOrder acceptOrder) throws WholeSalerException{
        try {
            wholeSalerDatabaseInterface.deleteOrder(acceptOrder);
        }catch (WholeSalerException w){
            throw new WholeSalerException(w.getMessage());
        }catch (Exception e){
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
        return "declined";
    }


}
