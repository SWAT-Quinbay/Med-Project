package com.example.WholeSalerDatabase.service;

import com.example.WholeSalerDatabase.customException.WholeSalerException;
import com.example.WholeSalerDatabase.jpa.WholeSalerDatabaseRepository;
import com.example.WholeSalerDatabase.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class  WholeSalerDatabaseService implements WholeSalerDatabaseInterface{

    @Autowired
    WholeSalerDatabaseRepository wholeSalerDatabaseRepository;

    RestTemplate restTemplate;

    public WholeSalerDatabaseService(RestTemplateBuilder restTemplateBuilder){
        restTemplate = restTemplateBuilder.build();
    }

    @Override
    public String addDetails(Details details){
        wholeSalerDatabaseRepository.save(details);
        return "done";
    }

    @Override
    public List<Details> getDetails(){
        return wholeSalerDatabaseRepository.findAll();
    }

    @Override
    public Optional<Details> getDetailsById(int id) throws WholeSalerException {

        Optional<Details> details = wholeSalerDatabaseRepository.findById(id);

        if(details.isPresent()){
            return details;
        }
        throw new WholeSalerException("Id not found");
    }

    @Override
    public List<OrderDetails> getOrders(){

        OrderDetails[] orderDetails = restTemplate.getForObject("http://localhost:8188/orders/getOrder",OrderDetails[].class);

        List<OrderDetails> orderAsList = Arrays.asList(orderDetails);



        return  orderAsList;

    }
    @Override
    public String updateOrder(RequestModel requestModel) throws WholeSalerException {
        OrderDetails orderDetails = new OrderDetails();
//        OrderDetails orderDetails = new OrderDetails(requestModel.getSellerId(), requestModel.getProductId(), requestModel.getProductName(), requestModel.getCount(), "pending");
        orderDetails.setUserId(requestModel.getSellerId());
        orderDetails.setProductId(requestModel.getProductId());
        orderDetails.setProductName(requestModel.getProductName());
        orderDetails.setStock(requestModel.getCount());
        orderDetails.setStatus("pending");
        orderDetails.setOrderid(0);
        OrderDetails orderDetails1 = restTemplate.postForObject("http://localhost:8188/orders/addOrder",orderDetails,OrderDetails.class);

        System.out.println(orderDetails.toString());

        if(orderDetails1 == null)
            throw new WholeSalerException("Order id not found");




        return "done";
    }

    @Override
    public List<Details> decrementStock(AcceptOrder acceptOrder) throws WholeSalerException {
        OrderDetails orderDetails;

        orderDetails = restTemplate.getForObject("http://localhost:8188/orders/getOrderById/" +acceptOrder.getOrderid(),OrderDetails.class);


        if(orderDetails == null)
            throw new WholeSalerException("Order id not found");


        List<Details> details1 = wholeSalerDatabaseRepository.findByProductName(orderDetails.getProductName());
        for(Details details2 : details1){
            details2.setStock(details2.getStock() - orderDetails.getStock());
            wholeSalerDatabaseRepository.save(details2);
        }

        boolean flag = restTemplate.postForObject("http://10.30.1.92:8081/incrementStock",orderDetails,Boolean.class);

        if(!flag)
            throw new WholeSalerException("Update failed.");

        deleteOrder(acceptOrder);
        System.out.println("Accept order");
        return details1;
    }


    public void deleteOrder(AcceptOrder acceptOrder) throws WholeSalerException {

        OrderDetails orderDetails;

        orderDetails = restTemplate.getForObject("http://localhost:8188/orders/getOrderById/" +acceptOrder.getOrderid(),OrderDetails.class);


        if(orderDetails.getProductName().isEmpty())
            throw new WholeSalerException("Order id not found");


        String result = restTemplate.getForObject("http://localhost:8188/orders/deleteOrder/"+orderDetails.getProductName(),String.class);

        if(result.isEmpty())
            throw new WholeSalerException("Product Not found");

        System.out.println("Decline order");

    }




}
