package com.example.WholeSalerDatabase.customException;

public class WholeSalerException extends Exception{
    public WholeSalerException(String message){super(message);}
}
