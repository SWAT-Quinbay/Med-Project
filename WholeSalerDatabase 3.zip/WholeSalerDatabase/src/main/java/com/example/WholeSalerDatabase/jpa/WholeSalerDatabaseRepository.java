package com.example.WholeSalerDatabase.jpa;

import com.example.WholeSalerDatabase.model.Details;
import com.example.WholeSalerDatabase.model.RequestModel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WholeSalerDatabaseRepository extends JpaRepository<Details,Integer> {

    List<Details> findByProductName(String productName);


}
