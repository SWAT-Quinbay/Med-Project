package com.example.WholeSalerDatabase.service;

import com.example.WholeSalerDatabase.customException.WholeSalerException;
import com.example.WholeSalerDatabase.model.AcceptOrder;
import com.example.WholeSalerDatabase.model.Details;
import com.example.WholeSalerDatabase.model.OrderDetails;
import com.example.WholeSalerDatabase.model.RequestModel;

import java.util.List;
import java.util.Optional;

public interface WholeSalerDatabaseInterface {

    public String addDetails(Details details);
    public List<Details> getDetails();
    public Optional<Details> getDetailsById(int id) throws WholeSalerException;
    public List<Details> decrementStock(AcceptOrder acceptOrder) throws WholeSalerException;
    public void deleteOrder(AcceptOrder acceptOrder) throws WholeSalerException;

        public List<OrderDetails> getOrders();
    String updateOrder(RequestModel requestModel) throws WholeSalerException;

}
