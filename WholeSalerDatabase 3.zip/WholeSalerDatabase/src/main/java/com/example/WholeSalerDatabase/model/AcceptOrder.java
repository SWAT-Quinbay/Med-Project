package com.example.WholeSalerDatabase.model;

public class AcceptOrder {

    public void setOrderid(int orderid) {
        this.orderid = orderid;
    }

    private int orderid;
    private String status;

    public int getOrderid() {
        return orderid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
