package com.example.Retailseller.Model;

import lombok.Data;

import java.util.List;

@Data
public class Validation {
    private boolean response;
    private String userId;
    private List<RetailSeller>products;
    private String role;
}
