package com.example.Retailseller.CustomException;

public class IDNotFoundException extends Exception {
    public IDNotFoundException(String str) {
        super(str);
    }
}
