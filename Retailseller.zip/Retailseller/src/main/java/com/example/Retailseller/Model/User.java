package com.example.Retailseller.Model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "users")
public class User {
    @Id
    @Column(name = "userid")
    private String userId;
    @Column(name = "password")
    private String password;
    @Column(name="role")
    private String role;
}
