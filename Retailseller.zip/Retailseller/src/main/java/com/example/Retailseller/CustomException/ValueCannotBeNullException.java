package com.example.Retailseller.CustomException;

public class ValueCannotBeNullException extends Exception{
    public ValueCannotBeNullException(String str){
        super(str);
    }
}
