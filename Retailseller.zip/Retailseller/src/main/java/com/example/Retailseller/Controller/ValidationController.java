package com.example.Retailseller.Controller;

import com.example.Retailseller.CustomException.ValueCannotBeNullException;
import com.example.Retailseller.Model.User;
import com.example.Retailseller.Model.Validation;
import com.example.Retailseller.Repository.UserDBrepository;
import com.example.Retailseller.Service.UserDBserviceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@CrossOrigin(origins = "http://localhost:8080")
@RequestMapping("/")
public class ValidationController {
    @Autowired
    UserDBserviceImp userDBserviceImp;
    @PostMapping("/validate")
    public Validation validate(@RequestBody User user) throws ValueCannotBeNullException {
        try {
            return userDBserviceImp.check(user);
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,e.getMessage());
        }
    }

}
