package com.example.Retailseller;

import org.springframework.beans.factory.annotation.Value;

public class Constant {
    public static String wholeSaleDetails="http://10.30.1.86:8183/wholesaler/getDetails";
}
