package com.example.Retailseller.Model;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name="retailseller",uniqueConstraints = @UniqueConstraint(columnNames = {"sellerid","productname"}))

public class RetailSeller {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="productid")
    private int productId;
    @Column(name="sellerid")
    private String retailSellerId;
    @Column(name = "stockinhand")
    private int stockInHand;
    @Column(name = "price")
    private int retailPrice;
    @Column(name = "productname")
    private String productName;
    @Column(name="imageurl")
    private String imageUrl;
}


