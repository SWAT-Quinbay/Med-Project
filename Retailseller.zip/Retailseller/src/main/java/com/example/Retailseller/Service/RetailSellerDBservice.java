package com.example.Retailseller.Service;

import com.example.Retailseller.CustomException.IDNotFoundException;
import com.example.Retailseller.CustomException.WholeSaleOrderException;
import com.example.Retailseller.Model.OrderFromWholeSale;
import com.example.Retailseller.Model.ProductOrder;
import com.example.Retailseller.Model.RetailSeller;

import java.util.List;

public interface RetailSellerDBservice {
    List<RetailSeller>getAll();

    boolean incrementSalesCount(OrderFromWholeSale orderFromWholeSale) throws IDNotFoundException, WholeSaleOrderException;

    void insertAll(List<RetailSeller> retailSellerList);

    List<RetailSeller> getById(String retailSellerId) throws IDNotFoundException;
    boolean updateSalesCount(List<ProductOrder>productOrderList);
}
