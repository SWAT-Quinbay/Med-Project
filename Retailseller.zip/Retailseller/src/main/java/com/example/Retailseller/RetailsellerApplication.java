package com.example.Retailseller;

import com.example.Retailseller.Model.RetailSeller;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetailsellerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetailsellerApplication.class, args);
	}


}
