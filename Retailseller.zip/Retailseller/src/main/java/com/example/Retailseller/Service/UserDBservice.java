package com.example.Retailseller.Service;

import com.example.Retailseller.CustomException.ValueCannotBeNullException;
import com.example.Retailseller.Model.User;
import com.example.Retailseller.Model.Validation;

public interface UserDBservice {
    public Validation check(User user) throws ValueCannotBeNullException;
}
