package com.example.Retailseller.Repository;

import com.example.Retailseller.Model.RetailSeller;
import com.example.Retailseller.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserDBrepository extends JpaRepository<User,String> {
}
