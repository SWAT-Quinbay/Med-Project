package com.example.Retailseller.CustomException;

public class WholeSaleOrderException extends Exception {
    public WholeSaleOrderException(String str){
        super(str);
    }
}
