package com.example.Retailseller.Service;

import com.example.Retailseller.Constant;
import com.example.Retailseller.CustomException.ValueCannotBeNullException;
import com.example.Retailseller.Model.RetailSeller;
import com.example.Retailseller.Model.User;
import com.example.Retailseller.Model.Validation;
import com.example.Retailseller.Repository.RetailSellerRepository;
import com.example.Retailseller.Repository.UserDBrepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.Optional;

@Service
public class UserDBserviceImp implements UserDBservice {
    @Autowired
    UserDBrepository userDBrepository;
    @Autowired
    RetailSellerRepository retailSellerRepository;

    private RestTemplate restTemplate;

    public UserDBserviceImp(RestTemplateBuilder restTemplateBuilder) {

        restTemplate = restTemplateBuilder.build();
    }

    @Override
    public Validation check(User user) throws ValueCannotBeNullException {
        Validation validation=new Validation();
        //System.out.println(user.toString());
        if(user.getUserId().length()==0) {
            throw new ValueCannotBeNullException("The User Id cannot be null");
        }
        boolean flag=false;
        Optional<User> result = userDBrepository.findById(user.getUserId());
        if(!result.isPresent()){
            validation.setResponse(false);
        }
        else{
            User userToCheckWith=userDBrepository.getById(user.getUserId());
            if(userToCheckWith.getPassword().equals(user.getPassword())&&userToCheckWith.getRole().equals(user.getRole())){
                flag=true;
                validation.setResponse(true);
            }
            else{
                validation.setResponse(false);
            }
        }
        if(flag&&user.getRole().equals("retailseller")){
          //  System.out.println(user);
            validation.setUserId(user.getUserId());
            validation.setProducts(retailSellerRepository.getByRetailSellerId(user.getUserId()));
            validation.setRole(user.getRole());
        }
        else if(flag&&user.getRole().equals("wholesaleseller")){
            System.out.println(user);
            validation.setUserId(user.getUserId());
            validation.setProducts(Arrays.asList(restTemplate.getForObject(Constant.wholeSaleDetails,RetailSeller[].class)));
            validation.setRole(user.getRole());
            System.out.println(validation);
        }
        return validation;
    }
}
