package com.example.Retailseller.Model;

import lombok.Data;

@Data
public class ProductOrder {
    private String retailSellerId;
    private String productName;
    private int stockOrdered;
}
