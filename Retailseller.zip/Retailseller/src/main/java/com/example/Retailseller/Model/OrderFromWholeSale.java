package com.example.Retailseller.Model;

import lombok.Data;

@Data
public class OrderFromWholeSale {
    private String userId;
    private int productId;
    private String productName;
    private int stock;
}
