package com.example.Retailseller.Repository;

import com.example.Retailseller.Model.RetailSeller;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;


public interface RetailSellerRepository extends JpaRepository<RetailSeller,String> {
    List<RetailSeller> getByRetailSellerId(String retailSellerId);
    Optional<RetailSeller> findByRetailSellerIdAndProductName(String retailSellerId, String productName);
}
//retailSellerId
//        productName