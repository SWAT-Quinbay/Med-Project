package com.example.Retailseller.Service;

import com.example.Retailseller.CustomException.IDNotFoundException;
import com.example.Retailseller.CustomException.WholeSaleOrderException;
import com.example.Retailseller.Model.OrderFromWholeSale;
import com.example.Retailseller.Model.ProductOrder;
import com.example.Retailseller.Model.RetailSeller;
import com.example.Retailseller.Repository.RetailSellerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class RetailSellerDBserviceImp implements RetailSellerDBservice {
    @Autowired
    public RetailSellerRepository retailSellerRepository;

    @Override
    public List<RetailSeller> getAll() {
        return retailSellerRepository.findAll();
    }


    @Override
    public List<RetailSeller> getById(String retailSellerId) throws IDNotFoundException {
        List<RetailSeller> retailSellerList=retailSellerRepository.getByRetailSellerId(retailSellerId);
        if(retailSellerList.isEmpty()){
            throw new IDNotFoundException("Id is not Found");
        }
        return retailSellerList;
    }

    @Override
    public boolean updateSalesCount(List<ProductOrder> productOrderList) {
        List<RetailSeller> retailSellerList = new ArrayList<>();
        for (ProductOrder productOrder : productOrderList) {
            //System.out.println(retailSellerRepository.findByRetailSellerIdAndProductName(productOrder.getRetailSellerId(), productOrder.getProductName()));
            Optional<RetailSeller> result = retailSellerRepository.findByRetailSellerIdAndProductName(productOrder.getRetailSellerId(), productOrder.getProductName());

            if (result.isPresent()) {
                RetailSeller retailSeller = result.get();
                retailSeller.setStockInHand(retailSeller.getStockInHand() - productOrder.getStockOrdered());
                retailSellerRepository.save(retailSeller);
                retailSellerList.add(retailSeller);
            }
        }
        return true;
    }

    @Override
    public boolean incrementSalesCount(OrderFromWholeSale orderFromWholeSale) throws IDNotFoundException, WholeSaleOrderException {
        if(orderFromWholeSale==null)
            throw new WholeSaleOrderException("Exception with wholesale deal");
        Optional<RetailSeller> retailSeller=retailSellerRepository.findByRetailSellerIdAndProductName(orderFromWholeSale.getUserId(),orderFromWholeSale.getProductName());
        if(retailSeller.isPresent()){
            retailSeller.get().setStockInHand(orderFromWholeSale.getStock());
            retailSellerRepository.save(retailSeller.get());
        }
        else
            throw new IDNotFoundException("The retail seller ID is not found");
        return true;
    }

    @Override
    public void insertAll(List<RetailSeller> retailSellerList) {
        retailSellerRepository.saveAll(retailSellerList);
    }
}
