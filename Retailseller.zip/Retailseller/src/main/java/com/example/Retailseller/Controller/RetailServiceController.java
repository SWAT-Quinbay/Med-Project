package com.example.Retailseller.Controller;

import com.example.Retailseller.CustomException.IDNotFoundException;
import com.example.Retailseller.CustomException.WholeSaleOrderException;
import com.example.Retailseller.Model.OrderFromWholeSale;
import com.example.Retailseller.Model.ProductOrder;
import com.example.Retailseller.Model.RetailSeller;
import com.example.Retailseller.Repository.RetailSellerRepository;
import com.example.Retailseller.Service.RetailSellerDBservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/")
public class RetailServiceController {
    @Autowired
    RetailSellerDBservice retailSellerDBservice;

    @GetMapping("/get/{RetailSellerId}")
    public List<RetailSeller> getById(@PathVariable (name = "RetailSellerId") String retailSellerId){
        try {
            return retailSellerDBservice.getById(retailSellerId);
        }
        catch (Exception e){
            throw new ResponseStatusException(HttpStatus.NOT_FOUND,e.getMessage());
        }
    }
    @GetMapping("/get/all")
    public List<RetailSeller> getByAll(){
        return retailSellerDBservice.getAll();
    }

    @PostMapping("/post")
    public void postRetailSellerDetails(@RequestBody List<RetailSeller> retailSellerList){
        retailSellerDBservice.insertAll(retailSellerList);
    }

    @PostMapping("/update")
    public boolean updateProductCount(@RequestBody List<ProductOrder> productOrderList){
        return retailSellerDBservice.updateSalesCount(productOrderList);
    }

    @PostMapping("/incrementStock")
    public boolean incrementStock(@RequestBody OrderFromWholeSale orderFromWholeSale){
       try {
           System.out.println(orderFromWholeSale);
           retailSellerDBservice.incrementSalesCount(orderFromWholeSale);
           return true;
       }
        catch (Exception e){
           throw new ResponseStatusException(HttpStatus.NOT_FOUND,e.getMessage());
        }
    }
}
