package com.example.Retailseller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetailsellerApplicationTests {

	@Test
	void contextLoads() {
	}

}
