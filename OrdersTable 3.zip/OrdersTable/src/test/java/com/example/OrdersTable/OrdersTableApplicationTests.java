package com.example.OrdersTable;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersTableApplicationTests {

	@Test
	void contextLoads() {
	}

}
