package com.example.OrdersTable.controller;

import com.example.OrdersTable.model.AcceptOrder;
import com.example.OrdersTable.model.OrderDetails;
import com.example.OrdersTable.service.OrderDetailsService;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("/orders")
public class OrdersController {

    @Autowired
    OrderDetailsService orderDetailsService;

    @PostMapping("/addOrder")
    public OrderDetails addOrder(@RequestBody OrderDetails orderDetails){
        try {
            orderDetailsService.addOrder(orderDetails);
        }catch (Exception e){
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }

        System.out.println("added order");
        return orderDetails;
    }

    @GetMapping("getOrderById/{id}")
    public OrderDetails getOrderById(@PathVariable("id") int id){
        try {
            return orderDetailsService.getOrderById(id);
        }catch (Exception e){
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }

    }

    @GetMapping("/getOrder")
    public List<OrderDetails> getOrder(){

        try {
            List<OrderDetails> orderDetails =  orderDetailsService.getOrder();


            return  orderDetails;
        }catch (Exception e){
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
    }

    @GetMapping("/deleteOrder/{productName}")
    public String deleteOrder(@PathVariable("productName") String productName){
        try {
            orderDetailsService.deleteOrder(productName);
        }catch (Exception e){
            throw  new ResponseStatusException(HttpStatus.BAD_REQUEST,e.getMessage());
        }
        return "deleted";
    }




}
