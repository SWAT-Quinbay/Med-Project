package com.example.OrdersTable.jpa;

import com.example.OrdersTable.model.OrderDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.util.List;

@Repository
@Transactional
public interface OrderDetailsRepositary extends JpaRepository<OrderDetails,Integer> {

    @Modifying
    @Query("delete from OrderDetails u where u.productName = ?1")
    void deleteByProductName(String productName);

}
