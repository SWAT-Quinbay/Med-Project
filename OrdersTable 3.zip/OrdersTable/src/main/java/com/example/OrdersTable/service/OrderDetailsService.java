package com.example.OrdersTable.service;
import java.util.List;
import java.util.Optional;

import com.example.OrdersTable.customException.OrdersTableException;
import com.example.OrdersTable.jpa.OrderDetailsRepositary;
import com.example.OrdersTable.model.OrderDetails;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class OrderDetailsService {

    @Autowired
    OrderDetailsRepositary orderDetailsRepositary;

    public String addOrder(OrderDetails orderDetails){
        System.out.println(orderDetails.toString());
        orderDetailsRepositary.save(orderDetails);
        return "done";
    }

    public List<OrderDetails> getOrder(){
        return orderDetailsRepositary.findAll();
    }

    public OrderDetails getOrderById(int id) throws OrdersTableException {

        Optional<OrderDetails> orderDetails = orderDetailsRepositary.findById(id);
        System.out.println(orderDetails.toString());
        if(orderDetails.isPresent()){
            return orderDetails.get();
        }
        throw new OrdersTableException("Id not found");
    }


    public String deleteOrder(String productName) throws OrdersTableException {
        try {
            orderDetailsRepositary.deleteByProductName(productName);
        }catch (Exception e){
            throw new OrdersTableException("Product Name not found");
        }
        return "deletedOrder";
    }


}
