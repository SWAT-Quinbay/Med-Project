package com.example.OrdersTable.customException;

public class OrdersTableException extends Exception {
    public OrdersTableException(String message){super(message);}
}
